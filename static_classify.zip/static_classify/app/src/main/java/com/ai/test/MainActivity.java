package com.ai.test;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileNotFoundException;

import com.jni.lib.SmartEngine;

public class MainActivity extends Activity
{
    private static final int SELECT_IMAGE = 1;

    private TextView infoResult;
    private ImageView imageView;
    private Bitmap yourSelectedImage = null;


    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    infoResult.setText((String) msg.obj);
                    break;
            }
        }
    };

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        SmartEngine.getInstance().init(getApplicationContext());

        infoResult = (TextView) findViewById(R.id.infoResult);
        imageView = (ImageView) findViewById(R.id.imageView);

        Button buttonImage = (Button) findViewById(R.id.buttonImage);
        buttonImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent i = new Intent(Intent.ACTION_PICK);
                i.setType("image/*");
                startActivityForResult(i, SELECT_IMAGE);
            }
        });

        Button buttonDetect = (Button) findViewById(R.id.buttonDetect);
        buttonDetect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if (yourSelectedImage == null)
                    return;

                infoResult.setText(SmartEngine.getInstance().predictBitmap(yourSelectedImage));
            }
        });

        Button btnTestAccuracy = (Button) findViewById(R.id.btnTestNcnn);
        btnTestAccuracy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                final ProgressDialog proDialog = android.app.ProgressDialog.show(MainActivity.this, "Test", "scene test ...");
                Thread thread = new Thread()
                {
                    public void run()
                    {
                        String result = "";
                        result = SmartEngine.TestAccuracy();
                        proDialog.dismiss();

                        Message msg = new Message();
                        msg.what = 1;
                        msg.obj = result;
                        mHandler.sendMessage(msg);
                    }
                };
                thread.start();
            }
        });

        Button btnTestCaffe = (Button) findViewById(R.id.btnTestCaffe);
        btnTestCaffe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
//                final ProgressDialog proDialog = android.app.ProgressDialog.show(MainActivity.this, "SpoofDetect", "caffe test ...");
//                Thread thread = new Thread()
//                {
//                    public void run()
//                    {
//                        String result = "Caffe\n";
//                        //result = TestUtil.TestAccuracyRate(getApplicationContext(), CaffeSpoofDetect.getInstance());
//                        proDialog.dismiss();
//
//                        Message msg = new Message();
//                        msg.what = 1;
//                        msg.obj = result;
//                        mHandler.sendMessage(msg);
//                    }
//                };
//                thread.start();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();

            try
            {
                if (requestCode == SELECT_IMAGE) {
//                    Bitmap bitmap = decodeUri(selectedImage);
//
//                    Bitmap rgba = bitmap.copy(Bitmap.Config.ARGB_8888, true);
//
//                    // resize to 227x227
//                    yourSelectedImage = Bitmap.createScaledBitmap(rgba, 227, 227, false);
                    yourSelectedImage = decodeUri2(selectedImage);

                    imageView.setImageBitmap(yourSelectedImage);
                }
            }
            catch (FileNotFoundException e)
            {
                Log.e("mumu", "FileNotFoundException");
                return;
            }
        }
    }

    private Bitmap decodeUri(Uri selectedImage) throws FileNotFoundException
    {
        // Decode image size
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o);

        // The new size we want to scale to
        final int REQUIRED_SIZE = 400;

        // Find the correct scale value. It should be the power of 2.
        int width_tmp = o.outWidth, height_tmp = o.outHeight;
        int scale = 1;
        while (true) {
            if (width_tmp / 2 < REQUIRED_SIZE
               || height_tmp / 2 < REQUIRED_SIZE) {
                break;
            }
            width_tmp /= 2;
            height_tmp /= 2;
            scale *= 2;
        }

        // Decode with inSampleSize
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = scale;
        return BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o2);
    }

    private Bitmap decodeUri2(Uri selectedImage) throws FileNotFoundException
    {
        // Decode image size
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o);

        int algo_img_size = 224;
        int x_sample = o.outWidth / algo_img_size;
        int y_sample = o.outHeight / algo_img_size;
        int t_sample = x_sample > y_sample ? y_sample : x_sample;
        if (0 == t_sample)
        {
            t_sample = 1;
        }
        o.inSampleSize = t_sample;
        o.inJustDecodeBounds = false;
        return BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o);
    }

}
