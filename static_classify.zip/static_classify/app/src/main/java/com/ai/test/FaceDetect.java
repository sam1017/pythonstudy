package com.ai.test;


import android.graphics.Bitmap;
import android.util.Log;
import com.qihoo.faceapi.QhFaceApi;
import com.qihoo.faceapi.util.QhFaceInfo;

public class FaceDetect
{
    public static void init()
    {
        QhFaceApi.qhFaceDetectInit("/sdcard/QhFaceModels", 1);
    }

    public static boolean detect(Bitmap image)
    {
        Log.d("mumu", "------------> detect : IN");
        QhFaceInfo[] faces = QhFaceApi.faceDetectBitmap(image, QhFaceApi.RESIZE_640, QhFaceApi.FACE_UP);
        if (faces != null && faces.length != 0)
        {
            Log.d("mumu", "------------> faces : " + faces.length);
            return true;
        }
        return false;
    }

    public static void uninit()
    {
        QhFaceApi.qhFaceDetectDestroy();
    }

}
