package com.jni.lib;

import android.graphics.Bitmap;
import android.content.Context;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;

public class SqueezeEngine extends SmartBase
{
    private native boolean InitNcnn(byte[] param, byte[] bin, byte[] words);
    public native String Classify(Bitmap bitmap);
    private native boolean Detect(Bitmap bitmap);
    static {
        System.loadLibrary("squeezencnn");
    }

    @Override
    public boolean init(Context context)
    {
        Log.d("mumu", "SqueezeEngine.Init IN");
        if (bInited) return true;

        byte[] param = null;
        byte[] bin = null;
        byte[] words = null;

        try
        {
            {
                InputStream assetsInputStream = context.getAssets().open("squeezenet.param.bin");
                int available = assetsInputStream.available();
                param = new byte[available];
                int byteCode = assetsInputStream.read(param);
                Log.e("mumu", "param-----> byteCode = " + byteCode);
                assetsInputStream.close();
            }

            {
                InputStream assetsInputStream = context.getAssets().open("squeezenet.bin");
                int available = assetsInputStream.available();
                bin = new byte[available];
                int byteCode = assetsInputStream.read(bin);
                Log.e("mumu", "model-----> byteCode = " + byteCode);
                assetsInputStream.close();
            }

            {
                InputStream assetsInputStream = context.getAssets().open("squeezenet.txt");
                int available = assetsInputStream.available();
                words = new byte[available];
                int byteCode = assetsInputStream.read(words);
                Log.e("mumu", "words-----> byteCode = " + byteCode);
                assetsInputStream.close();
            }

            InitNcnn(param, bin, words);
            bInited = true;
            return true;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            Log.e("mumu", "SqueezeEngine.Init error!");
            return false;
        }
    }


    @Override
    public String predictBitmap(Bitmap bitmap)
    {
        //Bitmap rgba = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        //Bitmap input_data = Bitmap.createScaledBitmap(rgba, 227, 227, false);

        if (bitmap.getWidth() != 227 || bitmap.getHeight() != 227)
        {
            Bitmap input_bitmap = Bitmap.createScaledBitmap(bitmap, 227, 227, false);
            return  Classify(input_bitmap);
        }

        return  Classify(bitmap);
    }


    @Override
    public boolean uninit()
    {
        return true;
    }


}
