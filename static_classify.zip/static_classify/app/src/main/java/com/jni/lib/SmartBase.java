package com.jni.lib;

import android.graphics.Bitmap;
import android.content.Context;
import android.util.Log;

public class SmartBase
{
    protected  boolean bInited = false;
    public boolean init(Context context)
    {
        Log.d("mumu", "SmartBase.init IN");
		return true;
    }

    public String predictBitmap(Bitmap bitmap)
    {
        Log.d("mumu", "SmartBase.predictBitmap IN");
		return "SmartBase";
    }

    public boolean uninit()
    {
        Log.d("mumu", "SmartBase.uninit IN");
        return true;
    }
}
