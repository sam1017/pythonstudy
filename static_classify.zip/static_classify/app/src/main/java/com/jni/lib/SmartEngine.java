package com.jni.lib;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

//import test.android.camera.FaceDetect;

public class SmartEngine {
    public static float SCORE_THRESHOLD = 0.6f;
    public static int MOBILENET_IMG_SIZE = 224;
    public static int SQUEEZENET_IMG_SIZE = 227;
    private static int algo_img_size = MOBILENET_IMG_SIZE;
    private static SmartEngine mSmartEngine = null;
    private SmartBase mSmartBase = null;
    private MTCNN mtcnn;
    public  final int MODEL_TYPE = 0; //0: tf mobilenet   1: caffe squeezenet

    private static String mScene1 = "auto";
    private static float mScore1 = 1.0f;
    private static String mScene2 = "auto";
    private static float mScore2 = 1.0f;
    private static int mImageNum = 0;

//    private ImageClassifier22 mImageClassifier22;

    public static SmartEngine getInstance() {
        if (mSmartEngine == null) {
            synchronized (SmartEngine.class) {
                if (mSmartEngine == null) {
                    mSmartEngine = new SmartEngine();
                }
            }
        }
        return mSmartEngine;
    }


    public boolean init(Context context)
    {
        String class_name;
        if (MODEL_TYPE == 0)
        {
            class_name = "com.jni.lib.ImageClassifier";
            algo_img_size = MOBILENET_IMG_SIZE;
        }
        else
        {
            class_name = "com.jni.lib.SqueezeEngine";
            algo_img_size = SQUEEZENET_IMG_SIZE;
        }

        try {
            Class clazz = Class.forName(class_name);
            mSmartBase = (SmartBase) clazz.newInstance();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (InstantiationException e) {
            e.printStackTrace();
            return false;
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            return false;
        }

        mtcnn = new MTCNN(context);
//        mImageClassifier22 =  new ImageClassifier22();
//        mImageClassifier22.init(context);

        return mSmartBase.init(context);
    }

    public String predictBitmap(Bitmap src_bitmap)
    {
        String result;
        Bitmap input_bitmap = Bitmap.createScaledBitmap(src_bitmap, algo_img_size, algo_img_size, true);

        int faceNum = mtcnn.getFaceNum(input_bitmap);        //if (faceNum > 0 && faceNum < 3)
        if (faceNum > 0)
        {
            mScore1 = 1.0f;
            mScene1 = "portrait";
            result = mScene1 + ":" + mScore1;
            return result;
        }


        result = mSmartBase.predictBitmap(input_bitmap);
        Log.d("mumu", "predictBitmap: " + result);
//        Log.d("mumu", "ImageClassifier22 predictBitmap: " + mImageClassifier22.predictBitmap(input_bitmap));

        if (MODEL_TYPE == 1)//caffe squeezenet
        {
            String [] top1 = result.split(":");
            mScore1 = Float.parseFloat(top1[1]);
            mScene1 = top1[0];
            result = mScene1 + ":" + mScore1;
            return result;
        }

        if (result == null) {
            return "auto:1.0";
        }
        String [] ret = result.split("\n");
        if (ret.length < 3) {
            return "auto:1.0";
        }
        String [] top1 = ret[1].split(":");
        String [] top2 = ret[2].split(":");
        mScene1 = top1[0];
        mScore1 = Float.parseFloat(top1[1]);
        mScene2 = top2[0];
        mScore2 = Float.parseFloat(top2[1]);


        if (mScene1.equalsIgnoreCase("cacti"))
        {
            mScene1 = "plants";
        }

        if (mScene1.equalsIgnoreCase("cat") || mScene1.equalsIgnoreCase("dog"))
        {
            mScene1 = "pet";
            if (mScene2.equalsIgnoreCase("cat") ||
                    mScene2.equalsIgnoreCase("dog") ||
                    mScene2.equalsIgnoreCase("pavement") &&
                            mScore1 > 0.3f)
            {
                mScore1 += mScore2;
            }
        }
        else if (mScene1.indexOf("building") >= 0)
        {
            mScene1 = "building";
            if (mScene2.indexOf("building") >= 0 || mScene2.equalsIgnoreCase("pavement"))
            {
                mScore1 = 1.0f;
            }
        }
        else if (mScene1.equalsIgnoreCase("portrait"))
        {
            if (mScene2.equalsIgnoreCase("noface"))
            {
                mScore1 += mScore2;
            }
        }
        else if (mScene1.equalsIgnoreCase("flower") || mScene1.equalsIgnoreCase("plants"))
        {
            if (mScene2.equalsIgnoreCase("flower") || mScene2.equalsIgnoreCase("plants"))
            {
                if(percentOfGreen(input_bitmap, 100) > 0.6f)
                {
                    if(percentOfGreen(input_bitmap, 50) > 0.6f)
                    {
                        mScene1 = "plants";
                    }
                    else if(percentOfGreen(input_bitmap, 50) < 0.3f)
                    {
                        mScene1 = "flower";
                    }
                }
                else if(percentOfGreen(input_bitmap, 100) < 0.3f)
                {
                    if(percentOfGreen(input_bitmap, 50) < 0.3f)
                    {
                        mScene1 = "flower";
                    }
                }

                mScore1 += mScore2;
            }
        }
        else if (mScene1.equalsIgnoreCase("bluesky"))
        {
            int main_color = blueOrRedYellow(input_bitmap);
            if(main_color == 0)
            {
                mScore1 = 1.0f;
            }
            else if (mScene2.equalsIgnoreCase("sunrise") && (main_color == 1))
            {
                mScene1 = "sunrise";
                mScore1 = 1.0f;
            }
            else if (main_color == 2)
            {
                mScene1 = "overcast";
            }
        }


        if (mScene1.equalsIgnoreCase("plants"))
        {
            if (mScene2.equalsIgnoreCase("autumn"))
            {
                if(percentOfGreen(input_bitmap, 200) > 0.3f)
                {
                    mScene1 = "plants";
                    mScore1 += mScore2;
                }
            }
        }
        else if (mScene1.equalsIgnoreCase("autumn"))
        {
            if (mScene2.equalsIgnoreCase("plants"))
            {
                if(percentOfGreen(input_bitmap, 200) > 0.6f)
                {
                    mScene1 = "plants";
                }
                mScore1 += mScore2;
            }
        }


        if (mScore1 < SCORE_THRESHOLD)
        {
            if (mScene1.equalsIgnoreCase("sunrise"))
            {
                if (mScene2.equalsIgnoreCase("bluesky"))
                {
                    int main_color = blueOrRedYellow(input_bitmap);
                    if(main_color == 1)
                    {
                        mScore1 = 1.0f;
                    }
                }
                else if (mScene2.equalsIgnoreCase("night") ||
                        mScene2.indexOf("building") >= 0 ||
                        mScene2.equalsIgnoreCase("plants") ||
                        mScene2.equalsIgnoreCase("beach"))
                {
                    if (mScore1 > 0.4f)mScore1 = 1.0f;//mScore1 += mScore2;
                }
            }
            else if (mScene1.equalsIgnoreCase("beach"))
            {
                if (mScene2.equalsIgnoreCase("bluesky"))
                {
                    if (mScore1 > 0.4f)mScore1 = 1.0f;//mScore1 += mScore2;
                }
            }
            else if (mScene1.equalsIgnoreCase("night"))
            {
                if (mScene2.equalsIgnoreCase("pavement") ||
                        mScene2.indexOf("building") >= 0 ||
                        mScene2.equalsIgnoreCase("plants") )
                {
                    if (mScore1 > 0.4f)mScore1 = 1.0f;//mScore1 += mScore2;
                }
            }
            else if (mScene1.equalsIgnoreCase("building"))
            {
                if (mScene2.equalsIgnoreCase("bluesky"))
                {
                    int main_color = blueOrRedYellow(input_bitmap);
                    if(main_color == 0)
                    {
                        mScene1 = "bluesky";
                        mScore1 = 1.0f;
                    }
                }
                else if (mScene2.equalsIgnoreCase("pavement") ||
                        mScene2.equalsIgnoreCase("plants") )
                {
                    if (mScore1 > 0.4f)mScore1 = 1.0f;//mScore1 += mScore2;
                }
                else if (mScene2.equalsIgnoreCase("night") )
                {
                    if (getMeanY(input_bitmap) > 90) mScore1 = 1.0f;
                }
            }



        }//end of if (mScore1 < SCORE_THRESHOLD)



        result = mScene1 + ":" + String.format(Locale.US, "%.2f", mScore1);
        return result;
    }

    public boolean uninit()
    {
        mSmartBase.uninit();
//        FaceDetect.uninit();
        return true;
    }


    /////////////////////////////////////////////////////////////////////////////////////////////////
    public static String TestAccuracy()
    {
        mImageNum = 0;
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("MMdd_HHmm");
        String failPath = "/sdcard/fail_" + sdf.format(d) + File.separator;
        File failDir = new File(failPath);
        Log.e("mumu", "failPath = " + failPath);
        if (!failDir.exists())
        {
            failDir.mkdirs();
        }

        String img_set_dir = "/sdcard/scene_test_set";
        File dir = new File(img_set_dir);
        int totalClassifyOK = 0;
        float accuracy;
        String result = "";
        long totaltime = 0, maxtime = 0, mintime = 5000;

        if (dir.listFiles() == null)
        {
            Log.e("mumu", "dir.listFiles() is NULL");
            return (img_set_dir + " no subdir");
        }
        Log.e("mumu", img_set_dir + "  listFiles() = " + dir.listFiles().length);

        BitmapFactory.Options options = new BitmapFactory.Options();
        for (File subdir : dir.listFiles())
        {
            if (subdir.listFiles() == null)
            {
                continue;
            }
            //Log.d(TAG, "to test subdir: " + subdir.getName());
            String failSubPath = failPath + subdir.getName() + File.separator;
            File failSubDir = new File(failSubPath);
            failSubDir.mkdirs();

            int nClassifyOK = 0;     int nClassifyOK_6 = 0; int nClassifyOK_7 = 0; int nClassifyOK_8 = 0;
            int nClassifyError = 0;  float accuracy6, accuracy7, accuracy8;
            for (File file : subdir.listFiles()) // iterate through picture directories
            {
                if (!file.getName().endsWith(".png") && !file.getName().endsWith(".jpg") &&
                        !file.getName().endsWith(".jpeg") && !file.getName().endsWith(".JPG") && !file.getName().endsWith(".JPEG"))
                {
                    continue;
                }

                mImageNum++;
                options.inJustDecodeBounds = true;
                options.inSampleSize = 1;
                BitmapFactory.decodeFile(file.getAbsolutePath(), options);
                //Log.d("mumu", "w = " + options.outWidth);
                int x_sample = options.outWidth / algo_img_size;
                int y_sample = options.outHeight / algo_img_size;
                int t_sample = x_sample > y_sample ? y_sample : x_sample;
                if (0 == t_sample)
                {
                    t_sample = 1;
                }
                options.inSampleSize = t_sample;
                options.inJustDecodeBounds = false;
                Bitmap src_bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);

                long startTime, endTime, timeCost;
                startTime = System.currentTimeMillis();
                String predictResult =SmartEngine.getInstance().predictBitmap(src_bitmap);
                endTime = System.currentTimeMillis();
                timeCost = endTime - startTime;

                String [] ret = predictResult.split(":");
                float score = Float.parseFloat(ret[1]);
                String scene = ret[0];
                Log.e("mumu", "predictBitmap, timecost: " + Long.toString(timeCost) + ", scene=" + scene + ", score=" + score);

                totaltime += timeCost;
                if (maxtime < timeCost)
                {
                    maxtime = timeCost;
                }
                if (mintime > timeCost)
                {
                    mintime = timeCost;
                }


                if (scene.equalsIgnoreCase(subdir.getName()))
                {
                    Log.e("mumu", mImageNum + "classify ok=" + file.getAbsolutePath());
                    nClassifyOK++;
                    if (score >= 0.6f)nClassifyOK_6++;
                    if (score >= 0.7f)nClassifyOK_7++;
                    if (score >= 0.8f)nClassifyOK_8++;

                    if (score < SCORE_THRESHOLD)
                    {
                        String filename = mImageNum + "_" + mScene1 + String.format("%.2f", mScore1) + "_" + mScene2 + String.format("%.2f", mScore2) + ".jpg";
                        saveBitmap(src_bitmap, failSubPath + filename);
                    }
                }
                else
                {
                    Log.e("mumu", mImageNum + "classify error=" + file.getAbsolutePath());
                    nClassifyError++;

                    String filename = mImageNum + "_" + mScene1 + String.format("%.2f", mScore1) + "_" + mScene2 + String.format("%.2f", mScore2) + ".jpg";
                    saveBitmap(src_bitmap, failSubPath + filename);
                }



                src_bitmap.recycle();
            }
            totalClassifyOK += nClassifyOK;
            int subdirTotalImages = nClassifyOK + nClassifyError;
            accuracy = (float)nClassifyOK * 100f / subdirTotalImages;
            result += subdir.getName() + ": " + nClassifyOK + "/" + subdirTotalImages + "=" + String.format("%.1f", accuracy) + "%";
            Log.e("mumu", "=====> [" + subdir.getName() + "], accuracy=" + nClassifyOK + "/" + subdirTotalImages + "=" + String.format("%.1f", accuracy) + "%");

            accuracy6 = (float)nClassifyOK_6 * 100f / subdirTotalImages;
            accuracy7 = (float)nClassifyOK_7 * 100f / subdirTotalImages;
            accuracy8 = (float)nClassifyOK_8 * 100f / subdirTotalImages;
            result += " [" + String.format("%.1f", accuracy6) + "] [" + String.format("%.1f", accuracy7) + "] [" + String.format("%.1f", accuracy8) + "]\n";
            Log.e("mumu", "               accuracy6=" + String.format("%.1f", accuracy6) + ", accuracy7=" + String.format("%.1f", accuracy7) + ", accuracy8=" + String.format("%.1f", accuracy8));
        }

        accuracy = (float)totalClassifyOK * 100f / mImageNum;
        result += "total: " + totalClassifyOK + " / " + mImageNum + " = " + String.format("%.1f", accuracy) + "%\n";
        Log.e("mumu", "totalAccuracy = " + totalClassifyOK + " / " + mImageNum + " = " + String.format("%.1f", accuracy) + "%");

        Log.e("mumu", "timecost mean = " + String.format("%.2f", (float)totaltime / mImageNum) );
        Log.e("mumu", "timecost max = " + Long.toString(maxtime));
        Log.e("mumu", "timecost min = " + Long.toString(mintime));
        result += "timecost mean = " + String.format("%.2f", (float)totaltime / mImageNum) + "\n";
        result += "timecost max = " + Long.toString(maxtime) + "\n";
        result += "timecost min = " + Long.toString(mintime) + "\n";
        return  result;
    }

    public static void saveBitmap(Bitmap bitmap, String picPath) {
        File f = new File(picPath);
        if (f.exists()) {
            return;
        }
        try {
            FileOutputStream out = new FileOutputStream(f);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public float percentOfGreen(Bitmap normalized_bitmap, int rect_width)
    {
        int width = normalized_bitmap.getWidth();
        int height = normalized_bitmap.getHeight();
        int yStart = (height - rect_width) / 2;
        int xStart = (width - rect_width) / 2;

        int yEnd = yStart + rect_width;
        int xEnd = xStart + rect_width;

        float[] hsv = new float[3];
        int num_green = 0;

        for(int y = yStart; y < yEnd; y++)
        {
            for (int x = xStart; x < xEnd; x++)
            {
                int tempColor = normalized_bitmap.getPixel(x, y);

                Color.RGBToHSV(Color.red(tempColor), Color.green(tempColor), Color.blue(tempColor), hsv);
                if (hsv[1] < 0.1f || hsv[2] < 0.1f)
                {
                    continue;
                }

                if (hsv[0] >= 70 && hsv[0] <= 150) {  //Green
                    num_green++;
                }
            }
        }

        float percent_green = (float) num_green / (rect_width * rect_width);

        boolean bDumpImage = false;
        if (bDumpImage)
        {
            String filename = mImageNum + "_" + String.format("%.2f", percent_green) + ".jpg";
            Bitmap center_rect = Bitmap.createBitmap(normalized_bitmap, xStart, yStart, rect_width, rect_width);
            saveBitmap(center_rect, "/sdcard/tf_50/" + filename);
        }

        return percent_green;
    }

    public int blueOrRedYellow(Bitmap normalized_bitmap)
    {
        int rect_width = 120;
        int width = normalized_bitmap.getWidth();
        int height = normalized_bitmap.getHeight();
        int yStart = 30;
        int xStart = (width - rect_width) / 2;

        int yEnd = yStart + rect_width;
        int xEnd = xStart + rect_width;

        float[] hsv = new float[3];
        int num_redyellow = 0;
        int num_blue = 0;

        for(int y = yStart; y < yEnd; y++)
        {
            for (int x = xStart; x < xEnd; x++)
            {
                int tempColor = normalized_bitmap.getPixel(x, y);

                Color.RGBToHSV(Color.red(tempColor), Color.green(tempColor), Color.blue(tempColor), hsv);

                //Log.d("mumu", "------> h = " + hsv[0] + ", s = " + hsv[1] + ", v = " + hsv[2]);
                if (hsv[1] < 0.1f || hsv[2] < 0.1f)
                {
                    continue;
                }

                if ((hsv[0] >= 0 && hsv[0] <= 70) || (hsv[0] > 330)) {  //redyellow
                    num_redyellow++;
                }else if (hsv[0] >= 190 && hsv[0] <= 250) {
                    num_blue++;
                }
            }
        }

        float percent_blue = (float) num_blue / (rect_width * rect_width);
        float percent_redyellow = (float) num_redyellow / (rect_width * rect_width);
        Log.d("mumu", "=====> blue: " + percent_blue + ",  redyellow: " + percent_redyellow);

        boolean bDumpImage = false;
        if (bDumpImage)
        {
            String filename = mImageNum + "_" + String.format("%.2f", percent_blue)  + "_" + String.format("%.2f", percent_redyellow) + ".jpg";
            Bitmap center_rect = Bitmap.createBitmap(normalized_bitmap, xStart, yStart, rect_width, rect_width);
            saveBitmap(center_rect, "/sdcard/tf_rect/" + filename);
        }

        if (percent_blue > 0.7f) {
            return 0;//bluesky
        }
        if (percent_redyellow > 0.4f) {
            return 1;
        }
        if (percent_blue < 0.1f && percent_redyellow > 0.2f) {
            return 1;
        }

        if (percent_blue < 0.1f) {
            return 2;
        }

        return -1;
    }

    public int getMeanY(Bitmap normalized_bitmap) {
        int width = normalized_bitmap.getWidth();
        int height = normalized_bitmap.getHeight();

        int[] intValues = new int[width * height];

        normalized_bitmap.getPixels(intValues, 0, width, 0, 0, width, height);
        int Y, R, G, B, Y_all = 0;
        int pixel = 0;
        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {
                final int val = intValues[pixel++];
                R = (val >> 16) & 0xFF;
                G = (val >> 8) & 0xFF;
                B = (val) & 0xFF;
                Y = ((66 * R + 129 * G + 25 * B + 128) >> 8) + 16;
                Y_all += Y;
            }
        }

        int y_mean = Y_all / (width * height);
        boolean bDumpImage = false;
        if (bDumpImage)
        {
            String filename = mImageNum + "_" + y_mean  + ".jpg";
            saveBitmap(normalized_bitmap, "/sdcard/tf_rect/" + filename);
        }

        return y_mean;
    }


    public static void saveBitmap222(Bitmap bitmap, int index) {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
        String picPath = "/sdcard/mumu/" + sdf.format(d) + "_" + index + ".jpg";
        File f = new File(picPath);
        if (f.exists()) {
            return;
        }
        try {
            FileOutputStream out = new FileOutputStream(f);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }




}
