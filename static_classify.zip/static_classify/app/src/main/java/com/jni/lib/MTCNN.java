package com.jni.lib;


import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Environment;
//import android.support.v4.app.ActivityCompat;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public class MTCNN {
    public native boolean FaceDetectionModelInit(String faceDetectionModelPath);
    public native int[] FaceDetect(byte[] imageDate, int imageWidth, int imageHeight, int imageChannel);
    public native boolean FaceDetectionModelUnInit();
    public native boolean SetMinFace(int newMinFaceSize);//default is 40
    static {
        System.loadLibrary("mtcnn");
    }


    private static final String TAG = "mumu";
    private Context mContext;


    public MTCNN(Context context) {
        mContext = context;
        init(mContext);
    }

    public int getFaceNum(Bitmap yourSelectedImage)
    {
        int width = yourSelectedImage.getWidth();
        int height = yourSelectedImage.getHeight();
        byte[] imageData = getPixelsRGBA(yourSelectedImage);

        //long timeDetectFace = System.currentTimeMillis();
        int faceInfo[]=FaceDetect(imageData,width,height,4);
        //timeDetectFace = System.currentTimeMillis() - timeDetectFace;
        //Log.e("mumu", "---mtcnn.FaceDetect timecost: " + timeDetectFace);

        if (faceInfo != null && faceInfo.length > 1)
        {
            return faceInfo[0];
        }
        else
        {
            return 0;
        }
    }

    private byte[] getPixelsRGBA(Bitmap image) {
        int bytes = image.getByteCount();
        ByteBuffer buffer = ByteBuffer.allocate(bytes); // Create a new buffer
        image.copyPixelsToBuffer(buffer); // Move the byte data to the buffer
        byte[] temp = buffer.array(); // Get the underlying array containing the

        return temp;
    }

    private void copyBigDataToSD(String strOutFileName) throws IOException {
        Log.i(TAG, "start copy file " + strOutFileName);
        File sdDir = Environment.getExternalStorageDirectory();
        File file = new File(sdDir.toString()+"/mtcnn/");
        if (!file.exists()) {
            file.mkdir();
        }

        String tmpFile = sdDir.toString()+"/mtcnn/" + strOutFileName;
        File f = new File(tmpFile);
        if (f.exists()) {
            Log.i(TAG, "file exists " + strOutFileName);
            return;
        }
        InputStream myInput;
        java.io.OutputStream myOutput = new FileOutputStream(sdDir.toString()+"/mtcnn/"+ strOutFileName);
        myInput = mContext.getAssets().open(strOutFileName);
        byte[] buffer = new byte[1024];
        int length = myInput.read(buffer);
        while (length > 0) {
            myOutput.write(buffer, 0, length);
            length = myInput.read(buffer);
        }
        myOutput.flush();
        myInput.close();
        myOutput.close();
        Log.i(TAG, "end copy file " + strOutFileName);
    }

    public void init(Context context)
    {
        mContext = context;
//        verifyStoragePermissions(context);
        try {
            copyBigDataToSD("det1.bin");
            copyBigDataToSD("det2.bin");
            copyBigDataToSD("det3.bin");
            copyBigDataToSD("det1.param");
            copyBigDataToSD("det2.param");
            copyBigDataToSD("det3.param");
        } catch (IOException e) {
            e.printStackTrace();
        }

        File sdDir = Environment.getExternalStorageDirectory();
        String sdPath = sdDir.toString() + "/mtcnn/";
        FaceDetectionModelInit(sdPath);
        SetMinFace(30);
    }
}
